<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-13 19:30:48 --> Config Class Initialized
INFO - 2023-08-13 19:30:48 --> Hooks Class Initialized
DEBUG - 2023-08-13 19:30:48 --> UTF-8 Support Enabled
INFO - 2023-08-13 19:30:48 --> Utf8 Class Initialized
INFO - 2023-08-13 19:30:48 --> URI Class Initialized
DEBUG - 2023-08-13 19:30:48 --> No URI present. Default controller set.
INFO - 2023-08-13 19:30:48 --> Router Class Initialized
INFO - 2023-08-13 19:30:48 --> Output Class Initialized
INFO - 2023-08-13 19:30:48 --> Security Class Initialized
DEBUG - 2023-08-13 19:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 19:30:48 --> Input Class Initialized
INFO - 2023-08-13 19:30:48 --> Language Class Initialized
INFO - 2023-08-13 19:30:48 --> Loader Class Initialized
INFO - 2023-08-13 19:30:48 --> Helper loaded: url_helper
INFO - 2023-08-13 19:30:48 --> Helper loaded: form_helper
INFO - 2023-08-13 19:30:48 --> Helper loaded: language_helper
INFO - 2023-08-13 19:30:48 --> Helper loaded: cookie_helper
INFO - 2023-08-13 19:30:48 --> Helper loaded: security_helper
INFO - 2023-08-13 19:30:48 --> Helper loaded: html_helper
INFO - 2023-08-13 19:30:48 --> Helper loaded: custom_helper
INFO - 2023-08-13 19:30:48 --> Database Driver Class Initialized
INFO - 2023-08-13 19:30:48 --> Email Class Initialized
ERROR - 2023-08-13 19:30:48 --> Severity: 8192 --> Return type of CI_Session_files_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 132
ERROR - 2023-08-13 19:30:48 --> Severity: 8192 --> Return type of CI_Session_files_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 294
ERROR - 2023-08-13 19:30:48 --> Severity: 8192 --> Return type of CI_Session_files_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 168
ERROR - 2023-08-13 19:30:48 --> Severity: 8192 --> Return type of CI_Session_files_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 237
ERROR - 2023-08-13 19:30:48 --> Severity: 8192 --> Return type of CI_Session_files_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 317
ERROR - 2023-08-13 19:30:48 --> Severity: 8192 --> Return type of CI_Session_files_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 358
ERROR - 2023-08-13 19:30:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 282
ERROR - 2023-08-13 19:30:48 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 294
ERROR - 2023-08-13 19:30:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 304
ERROR - 2023-08-13 19:30:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 314
ERROR - 2023-08-13 19:30:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 315
ERROR - 2023-08-13 19:30:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 316
ERROR - 2023-08-13 19:30:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 317
ERROR - 2023-08-13 19:30:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 375
ERROR - 2023-08-13 19:30:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 108
ERROR - 2023-08-13 19:30:48 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 110
ERROR - 2023-08-13 19:30:48 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 143
INFO - 2023-08-13 19:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 19:30:48 --> Model "Base_model" initialized
INFO - 2023-08-13 19:30:48 --> Controller Class Initialized
INFO - 2023-08-13 19:30:48 --> Model "Interlinx_reg_model" initialized
INFO - 2023-08-13 19:30:48 --> Model "Friends_model" initialized
INFO - 2023-08-13 19:30:48 --> Model "Meetings_model" initialized
INFO - 2023-08-13 19:30:48 --> Model "Messages_model" initialized
INFO - 2023-08-13 19:30:48 --> Model "Product_services_model" initialized
INFO - 2023-08-13 19:30:48 --> Model "Industry_sector_model" initialized
INFO - 2023-08-13 19:30:48 --> File loaded: /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/Taai/v-t3j45w1n!/login.php
INFO - 2023-08-13 19:30:48 --> Final output sent to browser
DEBUG - 2023-08-13 19:30:48 --> Total execution time: 0.0364
INFO - 2023-08-13 19:30:49 --> Config Class Initialized
INFO - 2023-08-13 19:30:49 --> Hooks Class Initialized
DEBUG - 2023-08-13 19:30:49 --> UTF-8 Support Enabled
INFO - 2023-08-13 19:30:49 --> Utf8 Class Initialized
INFO - 2023-08-13 19:30:49 --> URI Class Initialized
INFO - 2023-08-13 19:30:49 --> Router Class Initialized
INFO - 2023-08-13 19:30:49 --> Output Class Initialized
INFO - 2023-08-13 19:30:49 --> Security Class Initialized
DEBUG - 2023-08-13 19:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 19:30:49 --> Input Class Initialized
INFO - 2023-08-13 19:30:49 --> Language Class Initialized
ERROR - 2023-08-13 19:30:49 --> 404 Page Not Found: Assets/img
INFO - 2023-08-13 19:31:49 --> Config Class Initialized
INFO - 2023-08-13 19:31:49 --> Hooks Class Initialized
DEBUG - 2023-08-13 19:31:49 --> UTF-8 Support Enabled
INFO - 2023-08-13 19:31:49 --> Utf8 Class Initialized
INFO - 2023-08-13 19:31:49 --> URI Class Initialized
DEBUG - 2023-08-13 19:31:49 --> No URI present. Default controller set.
INFO - 2023-08-13 19:31:49 --> Router Class Initialized
INFO - 2023-08-13 19:31:49 --> Output Class Initialized
INFO - 2023-08-13 19:31:49 --> Security Class Initialized
DEBUG - 2023-08-13 19:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 19:31:49 --> Input Class Initialized
INFO - 2023-08-13 19:31:49 --> Language Class Initialized
INFO - 2023-08-13 19:31:49 --> Loader Class Initialized
INFO - 2023-08-13 19:31:49 --> Helper loaded: url_helper
INFO - 2023-08-13 19:31:49 --> Helper loaded: form_helper
INFO - 2023-08-13 19:31:49 --> Helper loaded: language_helper
INFO - 2023-08-13 19:31:49 --> Helper loaded: cookie_helper
INFO - 2023-08-13 19:31:49 --> Helper loaded: security_helper
INFO - 2023-08-13 19:31:49 --> Helper loaded: html_helper
INFO - 2023-08-13 19:31:49 --> Helper loaded: custom_helper
INFO - 2023-08-13 19:31:49 --> Database Driver Class Initialized
INFO - 2023-08-13 19:31:49 --> Email Class Initialized
ERROR - 2023-08-13 19:31:49 --> Severity: 8192 --> Return type of CI_Session_files_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 132
ERROR - 2023-08-13 19:31:49 --> Severity: 8192 --> Return type of CI_Session_files_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 294
ERROR - 2023-08-13 19:31:49 --> Severity: 8192 --> Return type of CI_Session_files_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 168
ERROR - 2023-08-13 19:31:49 --> Severity: 8192 --> Return type of CI_Session_files_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 237
ERROR - 2023-08-13 19:31:49 --> Severity: 8192 --> Return type of CI_Session_files_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 317
ERROR - 2023-08-13 19:31:49 --> Severity: 8192 --> Return type of CI_Session_files_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 358
ERROR - 2023-08-13 19:31:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 282
ERROR - 2023-08-13 19:31:49 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 294
ERROR - 2023-08-13 19:31:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 304
ERROR - 2023-08-13 19:31:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 314
ERROR - 2023-08-13 19:31:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 315
ERROR - 2023-08-13 19:31:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 316
ERROR - 2023-08-13 19:31:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 317
ERROR - 2023-08-13 19:31:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 375
ERROR - 2023-08-13 19:31:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 108
ERROR - 2023-08-13 19:31:49 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 110
ERROR - 2023-08-13 19:31:49 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 143
INFO - 2023-08-13 19:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 19:31:49 --> Model "Base_model" initialized
INFO - 2023-08-13 19:31:49 --> Controller Class Initialized
INFO - 2023-08-13 19:31:49 --> Model "Interlinx_reg_model" initialized
INFO - 2023-08-13 19:31:49 --> Model "Friends_model" initialized
INFO - 2023-08-13 19:31:49 --> Model "Meetings_model" initialized
INFO - 2023-08-13 19:31:49 --> Model "Messages_model" initialized
INFO - 2023-08-13 19:31:49 --> Model "Product_services_model" initialized
INFO - 2023-08-13 19:31:49 --> Model "Industry_sector_model" initialized
INFO - 2023-08-13 19:31:49 --> File loaded: /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/Taai/v-t3j45w1n!/login.php
INFO - 2023-08-13 19:31:49 --> Final output sent to browser
DEBUG - 2023-08-13 19:31:49 --> Total execution time: 0.0046
INFO - 2023-08-13 19:31:49 --> Config Class Initialized
INFO - 2023-08-13 19:31:49 --> Hooks Class Initialized
DEBUG - 2023-08-13 19:31:49 --> UTF-8 Support Enabled
INFO - 2023-08-13 19:31:49 --> Utf8 Class Initialized
INFO - 2023-08-13 19:31:49 --> URI Class Initialized
INFO - 2023-08-13 19:31:49 --> Router Class Initialized
INFO - 2023-08-13 19:31:49 --> Output Class Initialized
INFO - 2023-08-13 19:31:49 --> Security Class Initialized
DEBUG - 2023-08-13 19:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 19:31:49 --> Input Class Initialized
INFO - 2023-08-13 19:31:49 --> Language Class Initialized
ERROR - 2023-08-13 19:31:49 --> 404 Page Not Found: Assets/img
INFO - 2023-08-13 19:31:50 --> Config Class Initialized
INFO - 2023-08-13 19:31:50 --> Hooks Class Initialized
DEBUG - 2023-08-13 19:31:50 --> UTF-8 Support Enabled
INFO - 2023-08-13 19:31:50 --> Utf8 Class Initialized
INFO - 2023-08-13 19:31:50 --> URI Class Initialized
DEBUG - 2023-08-13 19:31:50 --> No URI present. Default controller set.
INFO - 2023-08-13 19:31:50 --> Router Class Initialized
INFO - 2023-08-13 19:31:50 --> Output Class Initialized
INFO - 2023-08-13 19:31:50 --> Security Class Initialized
DEBUG - 2023-08-13 19:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 19:31:50 --> Input Class Initialized
INFO - 2023-08-13 19:31:50 --> Language Class Initialized
INFO - 2023-08-13 19:31:50 --> Loader Class Initialized
INFO - 2023-08-13 19:31:50 --> Helper loaded: url_helper
INFO - 2023-08-13 19:31:50 --> Helper loaded: form_helper
INFO - 2023-08-13 19:31:50 --> Helper loaded: language_helper
INFO - 2023-08-13 19:31:50 --> Helper loaded: cookie_helper
INFO - 2023-08-13 19:31:50 --> Helper loaded: security_helper
INFO - 2023-08-13 19:31:50 --> Helper loaded: html_helper
INFO - 2023-08-13 19:31:50 --> Helper loaded: custom_helper
INFO - 2023-08-13 19:31:50 --> Database Driver Class Initialized
INFO - 2023-08-13 19:31:50 --> Email Class Initialized
ERROR - 2023-08-13 19:31:50 --> Severity: 8192 --> Return type of CI_Session_files_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 132
ERROR - 2023-08-13 19:31:50 --> Severity: 8192 --> Return type of CI_Session_files_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 294
ERROR - 2023-08-13 19:31:50 --> Severity: 8192 --> Return type of CI_Session_files_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 168
ERROR - 2023-08-13 19:31:50 --> Severity: 8192 --> Return type of CI_Session_files_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 237
ERROR - 2023-08-13 19:31:50 --> Severity: 8192 --> Return type of CI_Session_files_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 317
ERROR - 2023-08-13 19:31:50 --> Severity: 8192 --> Return type of CI_Session_files_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 358
ERROR - 2023-08-13 19:31:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 282
ERROR - 2023-08-13 19:31:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 294
ERROR - 2023-08-13 19:31:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 304
ERROR - 2023-08-13 19:31:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 314
ERROR - 2023-08-13 19:31:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 315
ERROR - 2023-08-13 19:31:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 316
ERROR - 2023-08-13 19:31:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 317
ERROR - 2023-08-13 19:31:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 375
ERROR - 2023-08-13 19:31:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 108
ERROR - 2023-08-13 19:31:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 110
ERROR - 2023-08-13 19:31:50 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 143
INFO - 2023-08-13 19:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 19:31:50 --> Model "Base_model" initialized
INFO - 2023-08-13 19:31:50 --> Controller Class Initialized
INFO - 2023-08-13 19:31:50 --> Model "Interlinx_reg_model" initialized
INFO - 2023-08-13 19:31:50 --> Model "Friends_model" initialized
INFO - 2023-08-13 19:31:50 --> Model "Meetings_model" initialized
INFO - 2023-08-13 19:31:50 --> Model "Messages_model" initialized
INFO - 2023-08-13 19:31:50 --> Model "Product_services_model" initialized
INFO - 2023-08-13 19:31:50 --> Model "Industry_sector_model" initialized
INFO - 2023-08-13 19:31:50 --> File loaded: /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/Taai/v-t3j45w1n!/login.php
INFO - 2023-08-13 19:31:50 --> Final output sent to browser
DEBUG - 2023-08-13 19:31:50 --> Total execution time: 0.0042
INFO - 2023-08-13 19:31:50 --> Config Class Initialized
INFO - 2023-08-13 19:31:50 --> Hooks Class Initialized
DEBUG - 2023-08-13 19:31:50 --> UTF-8 Support Enabled
INFO - 2023-08-13 19:31:50 --> Utf8 Class Initialized
INFO - 2023-08-13 19:31:50 --> URI Class Initialized
INFO - 2023-08-13 19:31:50 --> Router Class Initialized
INFO - 2023-08-13 19:31:50 --> Output Class Initialized
INFO - 2023-08-13 19:31:50 --> Security Class Initialized
DEBUG - 2023-08-13 19:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 19:31:50 --> Input Class Initialized
INFO - 2023-08-13 19:31:50 --> Language Class Initialized
ERROR - 2023-08-13 19:31:50 --> 404 Page Not Found: Assets/img
INFO - 2023-08-13 19:31:51 --> Config Class Initialized
INFO - 2023-08-13 19:31:51 --> Hooks Class Initialized
DEBUG - 2023-08-13 19:31:51 --> UTF-8 Support Enabled
INFO - 2023-08-13 19:31:51 --> Utf8 Class Initialized
INFO - 2023-08-13 19:31:51 --> URI Class Initialized
DEBUG - 2023-08-13 19:31:51 --> No URI present. Default controller set.
INFO - 2023-08-13 19:31:51 --> Router Class Initialized
INFO - 2023-08-13 19:31:51 --> Output Class Initialized
INFO - 2023-08-13 19:31:51 --> Security Class Initialized
DEBUG - 2023-08-13 19:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 19:31:51 --> Input Class Initialized
INFO - 2023-08-13 19:31:51 --> Language Class Initialized
INFO - 2023-08-13 19:31:51 --> Loader Class Initialized
INFO - 2023-08-13 19:31:51 --> Helper loaded: url_helper
INFO - 2023-08-13 19:31:51 --> Helper loaded: form_helper
INFO - 2023-08-13 19:31:51 --> Helper loaded: language_helper
INFO - 2023-08-13 19:31:51 --> Helper loaded: cookie_helper
INFO - 2023-08-13 19:31:51 --> Helper loaded: security_helper
INFO - 2023-08-13 19:31:51 --> Helper loaded: html_helper
INFO - 2023-08-13 19:31:51 --> Helper loaded: custom_helper
INFO - 2023-08-13 19:31:51 --> Database Driver Class Initialized
INFO - 2023-08-13 19:31:51 --> Email Class Initialized
ERROR - 2023-08-13 19:31:51 --> Severity: 8192 --> Return type of CI_Session_files_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 132
ERROR - 2023-08-13 19:31:51 --> Severity: 8192 --> Return type of CI_Session_files_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 294
ERROR - 2023-08-13 19:31:51 --> Severity: 8192 --> Return type of CI_Session_files_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 168
ERROR - 2023-08-13 19:31:51 --> Severity: 8192 --> Return type of CI_Session_files_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 237
ERROR - 2023-08-13 19:31:51 --> Severity: 8192 --> Return type of CI_Session_files_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 317
ERROR - 2023-08-13 19:31:51 --> Severity: 8192 --> Return type of CI_Session_files_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 358
ERROR - 2023-08-13 19:31:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 282
ERROR - 2023-08-13 19:31:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 294
ERROR - 2023-08-13 19:31:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 304
ERROR - 2023-08-13 19:31:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 314
ERROR - 2023-08-13 19:31:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 315
ERROR - 2023-08-13 19:31:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 316
ERROR - 2023-08-13 19:31:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 317
ERROR - 2023-08-13 19:31:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 375
ERROR - 2023-08-13 19:31:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/drivers/Session_files_driver.php 108
ERROR - 2023-08-13 19:31:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 110
ERROR - 2023-08-13 19:31:51 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/system/libraries/Session/Session.php 143
INFO - 2023-08-13 19:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 19:31:51 --> Model "Base_model" initialized
INFO - 2023-08-13 19:31:51 --> Controller Class Initialized
INFO - 2023-08-13 19:31:51 --> Model "Interlinx_reg_model" initialized
INFO - 2023-08-13 19:31:51 --> Model "Friends_model" initialized
INFO - 2023-08-13 19:31:51 --> Model "Meetings_model" initialized
INFO - 2023-08-13 19:31:51 --> Model "Messages_model" initialized
INFO - 2023-08-13 19:31:51 --> Model "Product_services_model" initialized
INFO - 2023-08-13 19:31:51 --> Model "Industry_sector_model" initialized
INFO - 2023-08-13 19:31:51 --> File loaded: /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/Taai/v-t3j45w1n!/login.php
INFO - 2023-08-13 19:31:51 --> Final output sent to browser
DEBUG - 2023-08-13 19:31:51 --> Total execution time: 0.0039
INFO - 2023-08-13 19:31:51 --> Config Class Initialized
INFO - 2023-08-13 19:31:51 --> Hooks Class Initialized
DEBUG - 2023-08-13 19:31:51 --> UTF-8 Support Enabled
INFO - 2023-08-13 19:31:51 --> Utf8 Class Initialized
INFO - 2023-08-13 19:31:51 --> URI Class Initialized
INFO - 2023-08-13 19:31:51 --> Router Class Initialized
INFO - 2023-08-13 19:31:51 --> Output Class Initialized
INFO - 2023-08-13 19:31:51 --> Security Class Initialized
DEBUG - 2023-08-13 19:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 19:31:51 --> Input Class Initialized
INFO - 2023-08-13 19:31:51 --> Language Class Initialized
ERROR - 2023-08-13 19:31:51 --> 404 Page Not Found: Assets/img
INFO - 2023-08-13 19:34:11 --> Config Class Initialized
INFO - 2023-08-13 19:34:11 --> Hooks Class Initialized
DEBUG - 2023-08-13 19:34:11 --> UTF-8 Support Enabled
INFO - 2023-08-13 19:34:11 --> Utf8 Class Initialized
INFO - 2023-08-13 19:34:11 --> URI Class Initialized
DEBUG - 2023-08-13 19:34:11 --> No URI present. Default controller set.
INFO - 2023-08-13 19:34:11 --> Router Class Initialized
INFO - 2023-08-13 19:34:11 --> Output Class Initialized
INFO - 2023-08-13 19:34:11 --> Security Class Initialized
DEBUG - 2023-08-13 19:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 19:34:11 --> Input Class Initialized
INFO - 2023-08-13 19:34:11 --> Language Class Initialized
INFO - 2023-08-13 19:34:11 --> Loader Class Initialized
INFO - 2023-08-13 19:34:11 --> Helper loaded: url_helper
INFO - 2023-08-13 19:34:11 --> Helper loaded: form_helper
INFO - 2023-08-13 19:34:11 --> Helper loaded: language_helper
INFO - 2023-08-13 19:34:11 --> Helper loaded: cookie_helper
INFO - 2023-08-13 19:34:11 --> Helper loaded: security_helper
INFO - 2023-08-13 19:34:11 --> Helper loaded: html_helper
INFO - 2023-08-13 19:34:11 --> Helper loaded: custom_helper
INFO - 2023-08-13 19:34:11 --> Database Driver Class Initialized
INFO - 2023-08-13 19:34:11 --> Email Class Initialized
INFO - 2023-08-13 19:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 19:34:11 --> Model "Base_model" initialized
INFO - 2023-08-13 19:34:11 --> Controller Class Initialized
INFO - 2023-08-13 19:34:11 --> Model "Interlinx_reg_model" initialized
INFO - 2023-08-13 19:34:11 --> Model "Friends_model" initialized
INFO - 2023-08-13 19:34:11 --> Model "Meetings_model" initialized
INFO - 2023-08-13 19:34:11 --> Model "Messages_model" initialized
INFO - 2023-08-13 19:34:11 --> Model "Product_services_model" initialized
INFO - 2023-08-13 19:34:11 --> Model "Industry_sector_model" initialized
INFO - 2023-08-13 19:34:11 --> File loaded: /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/Taai/v-t3j45w1n!/login.php
INFO - 2023-08-13 19:34:11 --> Final output sent to browser
DEBUG - 2023-08-13 19:34:11 --> Total execution time: 0.0275
INFO - 2023-08-13 19:34:11 --> Config Class Initialized
INFO - 2023-08-13 19:34:11 --> Hooks Class Initialized
DEBUG - 2023-08-13 19:34:11 --> UTF-8 Support Enabled
INFO - 2023-08-13 19:34:11 --> Utf8 Class Initialized
INFO - 2023-08-13 19:34:11 --> URI Class Initialized
INFO - 2023-08-13 19:34:11 --> Router Class Initialized
INFO - 2023-08-13 19:34:11 --> Output Class Initialized
INFO - 2023-08-13 19:34:11 --> Security Class Initialized
DEBUG - 2023-08-13 19:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 19:34:11 --> Input Class Initialized
INFO - 2023-08-13 19:34:11 --> Language Class Initialized
ERROR - 2023-08-13 19:34:11 --> 404 Page Not Found: Assets/img
INFO - 2023-08-13 19:34:14 --> Config Class Initialized
INFO - 2023-08-13 19:34:14 --> Hooks Class Initialized
DEBUG - 2023-08-13 19:34:14 --> UTF-8 Support Enabled
INFO - 2023-08-13 19:34:14 --> Utf8 Class Initialized
INFO - 2023-08-13 19:34:14 --> URI Class Initialized
DEBUG - 2023-08-13 19:34:14 --> No URI present. Default controller set.
INFO - 2023-08-13 19:34:14 --> Router Class Initialized
INFO - 2023-08-13 19:34:14 --> Output Class Initialized
INFO - 2023-08-13 19:34:14 --> Security Class Initialized
DEBUG - 2023-08-13 19:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 19:34:14 --> Input Class Initialized
INFO - 2023-08-13 19:34:14 --> Language Class Initialized
INFO - 2023-08-13 19:34:14 --> Loader Class Initialized
INFO - 2023-08-13 19:34:14 --> Helper loaded: url_helper
INFO - 2023-08-13 19:34:14 --> Helper loaded: form_helper
INFO - 2023-08-13 19:34:14 --> Helper loaded: language_helper
INFO - 2023-08-13 19:34:14 --> Helper loaded: cookie_helper
INFO - 2023-08-13 19:34:14 --> Helper loaded: security_helper
INFO - 2023-08-13 19:34:14 --> Helper loaded: html_helper
INFO - 2023-08-13 19:34:14 --> Helper loaded: custom_helper
INFO - 2023-08-13 19:34:14 --> Database Driver Class Initialized
INFO - 2023-08-13 19:34:14 --> Email Class Initialized
INFO - 2023-08-13 19:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 19:34:14 --> Model "Base_model" initialized
INFO - 2023-08-13 19:34:14 --> Controller Class Initialized
INFO - 2023-08-13 19:34:14 --> Model "Interlinx_reg_model" initialized
INFO - 2023-08-13 19:34:14 --> Model "Friends_model" initialized
INFO - 2023-08-13 19:34:14 --> Model "Meetings_model" initialized
INFO - 2023-08-13 19:34:14 --> Model "Messages_model" initialized
INFO - 2023-08-13 19:34:14 --> Model "Product_services_model" initialized
INFO - 2023-08-13 19:34:14 --> Model "Industry_sector_model" initialized
INFO - 2023-08-13 19:34:14 --> File loaded: /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/Taai/v-t3j45w1n!/login.php
INFO - 2023-08-13 19:34:14 --> Final output sent to browser
DEBUG - 2023-08-13 19:34:14 --> Total execution time: 0.0035
INFO - 2023-08-13 19:34:14 --> Config Class Initialized
INFO - 2023-08-13 19:34:14 --> Hooks Class Initialized
DEBUG - 2023-08-13 19:34:14 --> UTF-8 Support Enabled
INFO - 2023-08-13 19:34:14 --> Utf8 Class Initialized
INFO - 2023-08-13 19:34:14 --> URI Class Initialized
INFO - 2023-08-13 19:34:14 --> Router Class Initialized
INFO - 2023-08-13 19:34:14 --> Output Class Initialized
INFO - 2023-08-13 19:34:14 --> Security Class Initialized
DEBUG - 2023-08-13 19:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 19:34:14 --> Input Class Initialized
INFO - 2023-08-13 19:34:14 --> Language Class Initialized
ERROR - 2023-08-13 19:34:14 --> 404 Page Not Found: Assets/img
INFO - 2023-08-13 19:35:38 --> Config Class Initialized
INFO - 2023-08-13 19:35:38 --> Hooks Class Initialized
DEBUG - 2023-08-13 19:35:38 --> UTF-8 Support Enabled
INFO - 2023-08-13 19:35:38 --> Utf8 Class Initialized
INFO - 2023-08-13 19:35:38 --> URI Class Initialized
DEBUG - 2023-08-13 19:35:38 --> No URI present. Default controller set.
INFO - 2023-08-13 19:35:38 --> Router Class Initialized
INFO - 2023-08-13 19:35:38 --> Output Class Initialized
INFO - 2023-08-13 19:35:38 --> Security Class Initialized
DEBUG - 2023-08-13 19:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 19:35:38 --> Input Class Initialized
INFO - 2023-08-13 19:35:38 --> Language Class Initialized
INFO - 2023-08-13 19:35:38 --> Loader Class Initialized
INFO - 2023-08-13 19:35:38 --> Helper loaded: url_helper
INFO - 2023-08-13 19:35:38 --> Helper loaded: form_helper
INFO - 2023-08-13 19:35:38 --> Helper loaded: language_helper
INFO - 2023-08-13 19:35:38 --> Helper loaded: cookie_helper
INFO - 2023-08-13 19:35:38 --> Helper loaded: security_helper
INFO - 2023-08-13 19:35:38 --> Helper loaded: html_helper
INFO - 2023-08-13 19:35:38 --> Helper loaded: custom_helper
INFO - 2023-08-13 19:35:38 --> Database Driver Class Initialized
INFO - 2023-08-13 19:35:38 --> Email Class Initialized
INFO - 2023-08-13 19:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 19:35:38 --> Model "Base_model" initialized
INFO - 2023-08-13 19:35:38 --> Controller Class Initialized
INFO - 2023-08-13 19:35:38 --> Model "Interlinx_reg_model" initialized
INFO - 2023-08-13 19:35:38 --> Model "Friends_model" initialized
INFO - 2023-08-13 19:35:38 --> Model "Meetings_model" initialized
INFO - 2023-08-13 19:35:38 --> Model "Messages_model" initialized
INFO - 2023-08-13 19:35:38 --> Model "Product_services_model" initialized
INFO - 2023-08-13 19:35:38 --> Model "Industry_sector_model" initialized
INFO - 2023-08-13 19:35:38 --> File loaded: /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/Taai/v-t3j45w1n!/login.php
INFO - 2023-08-13 19:35:38 --> Final output sent to browser
DEBUG - 2023-08-13 19:35:38 --> Total execution time: 0.0034
INFO - 2023-08-13 19:35:38 --> Config Class Initialized
INFO - 2023-08-13 19:35:38 --> Hooks Class Initialized
DEBUG - 2023-08-13 19:35:38 --> UTF-8 Support Enabled
INFO - 2023-08-13 19:35:38 --> Utf8 Class Initialized
INFO - 2023-08-13 19:35:38 --> URI Class Initialized
INFO - 2023-08-13 19:35:38 --> Router Class Initialized
INFO - 2023-08-13 19:35:38 --> Output Class Initialized
INFO - 2023-08-13 19:35:38 --> Security Class Initialized
DEBUG - 2023-08-13 19:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 19:35:38 --> Input Class Initialized
INFO - 2023-08-13 19:35:38 --> Language Class Initialized
ERROR - 2023-08-13 19:35:38 --> 404 Page Not Found: Assets/img
INFO - 2023-08-13 19:35:40 --> Config Class Initialized
INFO - 2023-08-13 19:35:40 --> Hooks Class Initialized
DEBUG - 2023-08-13 19:35:40 --> UTF-8 Support Enabled
INFO - 2023-08-13 19:35:40 --> Utf8 Class Initialized
INFO - 2023-08-13 19:35:40 --> URI Class Initialized
DEBUG - 2023-08-13 19:35:40 --> No URI present. Default controller set.
INFO - 2023-08-13 19:35:40 --> Router Class Initialized
INFO - 2023-08-13 19:35:40 --> Output Class Initialized
INFO - 2023-08-13 19:35:40 --> Security Class Initialized
DEBUG - 2023-08-13 19:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 19:35:40 --> Input Class Initialized
INFO - 2023-08-13 19:35:40 --> Language Class Initialized
INFO - 2023-08-13 19:35:40 --> Loader Class Initialized
INFO - 2023-08-13 19:35:40 --> Helper loaded: url_helper
INFO - 2023-08-13 19:35:40 --> Helper loaded: form_helper
INFO - 2023-08-13 19:35:40 --> Helper loaded: language_helper
INFO - 2023-08-13 19:35:40 --> Helper loaded: cookie_helper
INFO - 2023-08-13 19:35:40 --> Helper loaded: security_helper
INFO - 2023-08-13 19:35:40 --> Helper loaded: html_helper
INFO - 2023-08-13 19:35:40 --> Helper loaded: custom_helper
INFO - 2023-08-13 19:35:40 --> Database Driver Class Initialized
INFO - 2023-08-13 19:35:40 --> Email Class Initialized
INFO - 2023-08-13 19:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 19:35:40 --> Model "Base_model" initialized
INFO - 2023-08-13 19:35:40 --> Controller Class Initialized
INFO - 2023-08-13 19:35:40 --> Model "Interlinx_reg_model" initialized
INFO - 2023-08-13 19:35:40 --> Model "Friends_model" initialized
INFO - 2023-08-13 19:35:40 --> Model "Meetings_model" initialized
INFO - 2023-08-13 19:35:40 --> Model "Messages_model" initialized
INFO - 2023-08-13 19:35:40 --> Model "Product_services_model" initialized
INFO - 2023-08-13 19:35:40 --> Model "Industry_sector_model" initialized
INFO - 2023-08-13 19:35:40 --> File loaded: /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/Taai/v-t3j45w1n!/login.php
INFO - 2023-08-13 19:35:40 --> Final output sent to browser
DEBUG - 2023-08-13 19:35:40 --> Total execution time: 0.0026
INFO - 2023-08-13 19:35:40 --> Config Class Initialized
INFO - 2023-08-13 19:35:40 --> Hooks Class Initialized
DEBUG - 2023-08-13 19:35:40 --> UTF-8 Support Enabled
INFO - 2023-08-13 19:35:40 --> Utf8 Class Initialized
INFO - 2023-08-13 19:35:40 --> URI Class Initialized
INFO - 2023-08-13 19:35:40 --> Router Class Initialized
INFO - 2023-08-13 19:35:40 --> Output Class Initialized
INFO - 2023-08-13 19:35:40 --> Security Class Initialized
DEBUG - 2023-08-13 19:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 19:35:40 --> Input Class Initialized
INFO - 2023-08-13 19:35:40 --> Language Class Initialized
ERROR - 2023-08-13 19:35:40 --> 404 Page Not Found: Assets/img
INFO - 2023-08-13 20:08:42 --> Config Class Initialized
INFO - 2023-08-13 20:08:42 --> Hooks Class Initialized
DEBUG - 2023-08-13 20:08:42 --> UTF-8 Support Enabled
INFO - 2023-08-13 20:08:42 --> Utf8 Class Initialized
INFO - 2023-08-13 20:08:42 --> URI Class Initialized
DEBUG - 2023-08-13 20:08:42 --> No URI present. Default controller set.
INFO - 2023-08-13 20:08:42 --> Router Class Initialized
INFO - 2023-08-13 20:08:42 --> Output Class Initialized
INFO - 2023-08-13 20:08:42 --> Security Class Initialized
DEBUG - 2023-08-13 20:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 20:08:42 --> Input Class Initialized
INFO - 2023-08-13 20:08:42 --> Language Class Initialized
INFO - 2023-08-13 20:08:42 --> Loader Class Initialized
INFO - 2023-08-13 20:08:42 --> Helper loaded: url_helper
INFO - 2023-08-13 20:08:42 --> Helper loaded: form_helper
INFO - 2023-08-13 20:08:42 --> Helper loaded: language_helper
INFO - 2023-08-13 20:08:42 --> Helper loaded: cookie_helper
INFO - 2023-08-13 20:08:42 --> Helper loaded: security_helper
INFO - 2023-08-13 20:08:42 --> Helper loaded: html_helper
INFO - 2023-08-13 20:08:42 --> Helper loaded: custom_helper
INFO - 2023-08-13 20:08:42 --> Database Driver Class Initialized
INFO - 2023-08-13 20:08:42 --> Email Class Initialized
INFO - 2023-08-13 20:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 20:08:42 --> Model "Base_model" initialized
INFO - 2023-08-13 20:08:42 --> Controller Class Initialized
INFO - 2023-08-13 20:08:42 --> Model "Interlinx_reg_model" initialized
INFO - 2023-08-13 20:08:42 --> Model "Friends_model" initialized
INFO - 2023-08-13 20:08:42 --> Model "Meetings_model" initialized
INFO - 2023-08-13 20:08:42 --> Model "Messages_model" initialized
INFO - 2023-08-13 20:08:42 --> Model "Product_services_model" initialized
INFO - 2023-08-13 20:08:42 --> Model "Industry_sector_model" initialized
INFO - 2023-08-13 20:08:42 --> File loaded: /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/Taai/v-t3j45w1n!/login.php
INFO - 2023-08-13 20:08:42 --> Final output sent to browser
DEBUG - 2023-08-13 20:08:42 --> Total execution time: 0.0302
INFO - 2023-08-13 20:08:43 --> Config Class Initialized
INFO - 2023-08-13 20:08:43 --> Hooks Class Initialized
DEBUG - 2023-08-13 20:08:43 --> UTF-8 Support Enabled
INFO - 2023-08-13 20:08:43 --> Utf8 Class Initialized
INFO - 2023-08-13 20:08:43 --> URI Class Initialized
INFO - 2023-08-13 20:08:43 --> Router Class Initialized
INFO - 2023-08-13 20:08:43 --> Output Class Initialized
INFO - 2023-08-13 20:08:43 --> Security Class Initialized
DEBUG - 2023-08-13 20:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 20:08:43 --> Input Class Initialized
INFO - 2023-08-13 20:08:43 --> Language Class Initialized
ERROR - 2023-08-13 20:08:43 --> 404 Page Not Found: Assets/img
INFO - 2023-08-13 20:10:46 --> Config Class Initialized
INFO - 2023-08-13 20:10:46 --> Hooks Class Initialized
DEBUG - 2023-08-13 20:10:46 --> UTF-8 Support Enabled
INFO - 2023-08-13 20:10:46 --> Utf8 Class Initialized
INFO - 2023-08-13 20:10:46 --> URI Class Initialized
DEBUG - 2023-08-13 20:10:46 --> No URI present. Default controller set.
INFO - 2023-08-13 20:10:46 --> Router Class Initialized
INFO - 2023-08-13 20:10:46 --> Output Class Initialized
INFO - 2023-08-13 20:10:46 --> Security Class Initialized
DEBUG - 2023-08-13 20:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 20:10:46 --> Input Class Initialized
INFO - 2023-08-13 20:10:46 --> Language Class Initialized
INFO - 2023-08-13 20:10:46 --> Loader Class Initialized
INFO - 2023-08-13 20:10:46 --> Helper loaded: url_helper
INFO - 2023-08-13 20:10:46 --> Helper loaded: form_helper
INFO - 2023-08-13 20:10:46 --> Helper loaded: language_helper
INFO - 2023-08-13 20:10:46 --> Helper loaded: cookie_helper
INFO - 2023-08-13 20:10:46 --> Helper loaded: security_helper
INFO - 2023-08-13 20:10:46 --> Helper loaded: html_helper
INFO - 2023-08-13 20:10:46 --> Helper loaded: custom_helper
INFO - 2023-08-13 20:10:46 --> Database Driver Class Initialized
INFO - 2023-08-13 20:10:46 --> Email Class Initialized
INFO - 2023-08-13 20:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 20:10:46 --> Model "Base_model" initialized
INFO - 2023-08-13 20:10:46 --> Controller Class Initialized
INFO - 2023-08-13 20:10:46 --> Model "Interlinx_reg_model" initialized
INFO - 2023-08-13 20:10:46 --> Model "Friends_model" initialized
INFO - 2023-08-13 20:10:46 --> Model "Meetings_model" initialized
INFO - 2023-08-13 20:10:46 --> Model "Messages_model" initialized
INFO - 2023-08-13 20:10:46 --> Model "Product_services_model" initialized
INFO - 2023-08-13 20:10:46 --> Model "Industry_sector_model" initialized
INFO - 2023-08-13 20:10:46 --> File loaded: /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/Taai/v-t3j45w1n!/login.php
INFO - 2023-08-13 20:10:46 --> Final output sent to browser
DEBUG - 2023-08-13 20:10:46 --> Total execution time: 0.0044
INFO - 2023-08-13 20:12:31 --> Config Class Initialized
INFO - 2023-08-13 20:12:31 --> Hooks Class Initialized
DEBUG - 2023-08-13 20:12:31 --> UTF-8 Support Enabled
INFO - 2023-08-13 20:12:31 --> Utf8 Class Initialized
INFO - 2023-08-13 20:12:31 --> URI Class Initialized
DEBUG - 2023-08-13 20:12:31 --> No URI present. Default controller set.
INFO - 2023-08-13 20:12:31 --> Router Class Initialized
INFO - 2023-08-13 20:12:31 --> Output Class Initialized
INFO - 2023-08-13 20:12:31 --> Security Class Initialized
DEBUG - 2023-08-13 20:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-13 20:12:31 --> Input Class Initialized
INFO - 2023-08-13 20:12:31 --> Language Class Initialized
INFO - 2023-08-13 20:12:31 --> Loader Class Initialized
INFO - 2023-08-13 20:12:31 --> Helper loaded: url_helper
INFO - 2023-08-13 20:12:31 --> Helper loaded: form_helper
INFO - 2023-08-13 20:12:31 --> Helper loaded: language_helper
INFO - 2023-08-13 20:12:31 --> Helper loaded: cookie_helper
INFO - 2023-08-13 20:12:31 --> Helper loaded: security_helper
INFO - 2023-08-13 20:12:31 --> Helper loaded: html_helper
INFO - 2023-08-13 20:12:31 --> Helper loaded: custom_helper
INFO - 2023-08-13 20:12:31 --> Database Driver Class Initialized
INFO - 2023-08-13 20:12:31 --> Email Class Initialized
INFO - 2023-08-13 20:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-13 20:12:31 --> Model "Base_model" initialized
INFO - 2023-08-13 20:12:31 --> Controller Class Initialized
INFO - 2023-08-13 20:12:31 --> Model "Interlinx_reg_model" initialized
INFO - 2023-08-13 20:12:31 --> Model "Friends_model" initialized
INFO - 2023-08-13 20:12:31 --> Model "Meetings_model" initialized
INFO - 2023-08-13 20:12:31 --> Model "Messages_model" initialized
INFO - 2023-08-13 20:12:31 --> Model "Product_services_model" initialized
INFO - 2023-08-13 20:12:31 --> Model "Industry_sector_model" initialized
INFO - 2023-08-13 20:12:31 --> File loaded: /home/u623622947/domains/interlinxpartnering.com/public_html/interlinx-2023/Taai/v-t3j45w1n!/login.php
INFO - 2023-08-13 20:12:31 --> Final output sent to browser
DEBUG - 2023-08-13 20:12:31 --> Total execution time: 0.0038
